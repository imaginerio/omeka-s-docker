<?php
namespace OaiPmhRepository\OaiPmh\OaiSet;

class Basic extends AbstractOaiSet
{
}
