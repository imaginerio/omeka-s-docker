# MetadataBrowse

This module will make it possible for users to view a browse page of all Resources that share a value for a particular metadata field.

See the [Omeka S user manual](http://dev.omeka.org/docs/s/user-manual/modules/metadatabrowse/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://dev.omeka.org/docs/s/user-manual/modules/#installing-modules)
