<?php
namespace Omeka\Api\Exception;

class BadRequestException extends RuntimeException
{
}
