# DSpace Connector

Connect an Omeka S instance to a DSpace repository, optionally importing files. The repository must be using DSpace version 4 or higher.

Information about the original item and a link back to it will be included on the imported item's page.

See the [Omeka S user manual](http://dev.omeka.org/docs/s/user-manual/modules/dspaceconnector/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://dev.omeka.org/docs/s/user-manual/modules/#installing-modules)
