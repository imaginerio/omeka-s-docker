<?php
namespace CSVImport\MediaIngesterAdapter;

interface MediaIngesterAdapterInterface
{
    public function getJson($mediaDatum);
}
