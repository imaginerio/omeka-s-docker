# Alt Text

An Omeka S module to allow users to specify custom alt text for media.

The Alt Text module requires at least Omeka S 1.2.0.
