# CSVImport

This module will allow users to import Entities from a simple CSV (comma separated value) file, and then map the CSV column data to Entity. Each row in the file represents metadata for a single Entity.

Most often, the import will create new Omeka S Items. It is also possible to import Users, and other modules can add other import types.

See the [Omeka S user manual](http://dev.omeka.org/docs/s/user-manual/modules/csvimport/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://dev.omeka.org/docs/s/user-manual/modules/#installing-modules)
