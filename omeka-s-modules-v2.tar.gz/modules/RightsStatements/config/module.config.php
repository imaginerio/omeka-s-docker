<?php
return [
    'data_types' => [
        'invokables' => [
            'rights_statement' => 'RightsStatements\DataType\RightsStatement'
        ],
    ],
];
