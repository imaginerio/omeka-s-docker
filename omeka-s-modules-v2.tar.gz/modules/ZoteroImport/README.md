# ZoteroImport

Import items from Zotero to Omeka S

See the [Omeka S user manual](http://dev.omeka.org/docs/s/user-manual/modules/zoteroimport/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://dev.omeka.org/docs/s/user-manual/modules/#installing-modules)
