# Sharing
Omeka S module for sharing content via 1) Social Media and 2) Embedding Omeka S content in other sites

See the [Omeka S user manual](http://dev.omeka.org/docs/s/user-manual/modules/sharing/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://dev.omeka.org/docs/s/user-manual/modules/#installing-modules)
