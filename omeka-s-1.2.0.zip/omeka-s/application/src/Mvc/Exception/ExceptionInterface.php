<?php
namespace Omeka\Mvc\Exception;

interface ExceptionInterface
{
}
