<?php
namespace Omeka\Form\Element;

class PropertySelect extends AbstractVocabularyMemberSelect
{
    public function getResourceName()
    {
        return 'properties';
    }
}
