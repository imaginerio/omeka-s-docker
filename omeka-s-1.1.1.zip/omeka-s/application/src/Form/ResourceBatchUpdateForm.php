<?php
namespace Omeka\Form;

use Zend\Form\Form;

class ResourceBatchUpdateForm extends Form
{
    public function init()
    {
    }
}
