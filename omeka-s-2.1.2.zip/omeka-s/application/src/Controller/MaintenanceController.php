<?php
namespace Omeka\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class MaintenanceController extends AbstractActionController
{
    public function indexAction()
    {
    }
}
