<?php
namespace Omeka\Module\Exception;

class ModuleStateInvalidException extends \RuntimeException implements ExceptionInterface
{
}
