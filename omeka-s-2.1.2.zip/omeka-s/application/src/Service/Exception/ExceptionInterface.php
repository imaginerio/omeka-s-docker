<?php
namespace Omeka\Service\Exception;

interface ExceptionInterface
{
}
