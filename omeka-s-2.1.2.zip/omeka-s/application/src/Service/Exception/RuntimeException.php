<?php
namespace Omeka\Service\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
