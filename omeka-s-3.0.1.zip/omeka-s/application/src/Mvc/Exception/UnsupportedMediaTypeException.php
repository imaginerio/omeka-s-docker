<?php
namespace Omeka\Mvc\Exception;

class UnsupportedMediaTypeException extends RuntimeException
{
}
