<?php
namespace Omeka\Module\Exception;

interface ExceptionInterface
{
}
