jQuery(document).ready(function(){
    Mirador.viewer(miradorConfig);
});
