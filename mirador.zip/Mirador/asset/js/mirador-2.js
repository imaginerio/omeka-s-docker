jQuery(document).ready(function(){
    Mirador(miradorConfig);
});
