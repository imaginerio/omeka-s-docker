# PDF Embed (for Omeka S)

An Omeka S module to embed PDFs directly in file or item pages.

Embedding on public item pages will only occur if the site's "Embed media on
item pages" setting is enabled.

For the time being, this module simply uses an `iframe` pointing to the PDF
file, relying on the browser to do the rendering itself.
